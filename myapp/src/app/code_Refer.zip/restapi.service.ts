import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RESTAPIService {
  url: string = "http://localhost:6000/";

  constructor(private http: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };
  
  addUser(user: any) {
    return this.http.post(this.url+"adduser", user, this.httpOptions);
  }

  getProducts() {
    return this.http.get(this.url+"getproducts", this.httpOptions);
  }

  addProduct(product: any) {
    return this.http.post(this.url+"addproduct", product, this.httpOptions);
  }
}